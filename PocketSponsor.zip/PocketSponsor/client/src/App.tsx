import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/landing";
import Home from "@/pages/home";
import Chat from "@/pages/chat";
import Resources from "@/pages/resources";
import Progress from "@/pages/progress";
import Pricing from "@/pages/pricing";
import SponsorDashboard from "@/pages/sponsor-dashboard";

// Wrap router in a Layout component to ensure consistent structure
function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      {children}
    </div>
  );
}

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/dashboard" component={Home} />
        <Route path="/chat" component={Chat} />
        <Route path="/resources" component={Resources} />
        <Route path="/progress" component={Progress} />
        <Route path="/pricing" component={Pricing} />
        <Route path="/sponsor-dashboard" component={SponsorDashboard} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}