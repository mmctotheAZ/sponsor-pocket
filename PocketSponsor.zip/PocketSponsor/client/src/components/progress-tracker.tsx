import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function ProgressTracker({ userId }: { userId: number }) {
  const [mood, setMood] = useState(5);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { mutate, isPending } = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/progress", {
        userId,
        mood,
        notes,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Progress Saved",
        description: "Your progress has been recorded.",
      });
      setNotes("");
      queryClient.invalidateQueries({ queryKey: ["/api/progress", userId] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save progress. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Check-in</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium mb-2 block">
            How are you feeling today? ({mood}/10)
          </label>
          <Slider
            value={[mood]}
            onValueChange={(values) => setMood(values[0])}
            min={1}
            max={10}
            step={1}
            className="mb-4"
          />
        </div>

        <div>
          <label className="text-sm font-medium mb-2 block">
            Notes (optional)
          </label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Any thoughts or reflections..."
            className="mb-4"
          />
        </div>

        <Button
          onClick={() => mutate()}
          disabled={isPending}
          className="w-full"
        >
          Save Progress
        </Button>
      </CardContent>
    </Card>
  );
}
