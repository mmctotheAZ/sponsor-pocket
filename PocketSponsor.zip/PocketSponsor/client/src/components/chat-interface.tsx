import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Send, Clock, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type Message = {
  content: string;
  isUser: boolean;
  timestamp?: string;
};

export function ChatInterface({ userId }: { userId: number }) {
  const [message, setMessage] = useState("");
  const [chatMessages, setChatMessages] = useState<Message[]>([]);
  const { toast } = useToast();

  // For demo, we'll hardcode PST time availability
  const now = new Date();
  const pstHour = now.getHours() - 3; // Simple PST conversion
  const isInAvailableHours = pstHour >= 8 && pstHour < 22;

  const { mutate: sendMessage, isPending } = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", "/api/chat", {
        userId,
        content,
        isUser: true
      });
      return res.json();
    },
    onSuccess: (data) => {
      setMessage("");
      const timestamp = new Date().toLocaleTimeString();
      setChatMessages(prev => [
        ...prev,
        { content: message, isUser: true, timestamp },
        { content: data.sponsorMessage.content, isUser: false, timestamp }
      ]);
    },
    onError: (error: Error) => {
      console.error("Chat error:", error);
      toast({
        title: "Error Sending Message",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="flex flex-col h-screen max-h-screen bg-background">
      <div className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <User className="h-5 w-5 text-primary" />
            <span className="font-semibold">Personal Sponsor Support</span>
          </div>
          <div className="flex items-center space-x-2">
            <Clock className="h-4 w-4" />
            <Badge variant={isInAvailableHours ? "default" : "secondary"}>
              {isInAvailableHours ? "Available" : "Away"}
            </Badge>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-2">
          {isInAvailableHours 
            ? "Sponsors typically respond within 15 minutes to 2 hours during business hours (8 AM - 10 PM PST)"
            : "Sponsors are currently away. Messages will be answered starting 8 AM PST"}
        </p>
      </div>

      <div className="flex-1 p-4">
        <ScrollArea className="h-full pr-4">
          <div className="space-y-4">
            {chatMessages.map((msg, index) => (
              <div
                key={index}
                className={`flex ${msg.isUser ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[80%] p-4 rounded-lg ${
                    msg.isUser
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  <div className="flex flex-col">
                    <div className="break-words">{msg.content}</div>
                    {msg.timestamp && (
                      <span className="text-xs opacity-70 mt-1">
                        {msg.timestamp}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      <div className="p-4 border-t bg-background">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (message.trim()) {
              sendMessage(message);
            }
          }}
          className="flex gap-2"
        >
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={isInAvailableHours 
              ? "Type your message here..."
              : "Type your message here. Note: Responses will resume at 8 AM PST"}
            className="min-h-[60px] flex-1"
          />
          <Button type="submit" size="icon" disabled={isPending || !message.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}