import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, Ambulance, Users, Heart } from "lucide-react";

export function EmergencyResources() {
  const resources = [
    {
      title: "Emergency Services",
      description: "If you're in immediate danger",
      icon: Ambulance,
      action: "Call 911",
      phone: "911",
      urgent: true,
    },
    {
      title: "National Crisis Helpline",
      description: "24/7 Support",
      icon: Phone,
      action: "Call Helpline",
      phone: "1-800-662-4357",
    },
    {
      title: "Find Local AA Meeting",
      description: "Connect with your community",
      icon: Users,
      action: "Find Meeting",
      link: "https://www.aa.org/find-aa",
    },
    {
      title: "Additional Support",
      description: "Other recovery resources",
      icon: Heart,
      action: "View Resources",
      link: "https://www.samhsa.gov/find-help",
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {resources.map((resource) => (
        <Card
          key={resource.title}
          className={resource.urgent ? "border-red-500" : undefined}
        >
          <CardHeader className="flex flex-row items-center gap-2">
            <resource.icon className="h-6 w-6 text-primary" />
            <CardTitle className="text-lg">{resource.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground mb-4">{resource.description}</p>
            <Button
              className="w-full"
              onClick={() => {
                if (resource.phone) {
                  window.location.href = `tel:${resource.phone}`;
                } else if (resource.link) {
                  window.open(resource.link, "_blank");
                }
              }}
            >
              {resource.action}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
