import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Home, MessageCircle, BarChart2, LifeBuoy } from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();

  const links = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/chat", icon: MessageCircle, label: "Chat" },
    { href: "/progress", icon: BarChart2, label: "Progress" },
    { href: "/resources", icon: LifeBuoy, label: "Resources" },
  ];

  return (
    <div className="h-screen w-[200px] border-r bg-sidebar p-4 flex flex-col gap-2">
      {links.map(({ href, icon: Icon, label }) => (
        <Link key={href} href={href}>
          <Button
            variant={location === href ? "secondary" : "ghost"}
            className={cn(
              "w-full justify-start gap-2",
              location === href && "bg-sidebar-accent text-sidebar-accent-foreground"
            )}
          >
            <Icon className="h-4 w-4" />
            {label}
          </Button>
        </Link>
      ))}
    </div>
  );
}
