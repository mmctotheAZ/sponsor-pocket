import { Sidebar } from "@/components/ui/sidebar";
import { ChatInterface } from "@/components/chat-interface";

export default function Chat() {
  // TODO: Get actual user ID from auth context
  const userId = 1;

  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1">
        <ChatInterface userId={userId} />
      </main>
    </div>
  );
}
