import { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { useToast } from "@/hooks/use-toast";
import { Sidebar } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import { Check } from "lucide-react";

const stripePromise = (async () => {
  const key = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY;
  if (!key) {
    throw new Error("Missing Stripe publishable key");
  }

  if (!key.startsWith('pk_test_')) {
    throw new Error("Development environment requires a test mode publishable key (starts with pk_test_)");
  }

  try {
    console.log("Initializing Stripe in test mode...");
    const stripe = await loadStripe(key);
    if (!stripe) {
      throw new Error("Failed to initialize Stripe");
    }
    console.log("Stripe initialized successfully");
    return stripe;
  } catch (error) {
    console.error("Stripe initialization error:", error);
    throw error;
  }
})();

export default function Pricing() {
  const [isLoading, setIsLoading] = useState<"session" | "subscription" | null>(null);
  const { toast } = useToast();

  const handlePayment = async (type: "session" | "subscription") => {
    try {
      setIsLoading(type);
      console.log(`Initiating ${type} payment...`);
      const stripe = await stripePromise;

      if (!stripe) {
        throw new Error("Stripe is not properly configured. Please try again later.");
      }

      let response;
      if (type === "session") {
        response = await fetch("/api/payments/create-intent", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ productType: "SINGLE_SESSION" })
        });
      } else {
        const email = "test@example.com"; // TODO: Get from auth context
        response = await fetch("/api/payments/create-subscription", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email })
        });
      }

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Payment request failed");
      }

      const data = await response.json();
      console.log(`Payment ${type} intent created successfully`);

      const { error } = await stripe.confirmPayment({
        clientSecret: data.clientSecret,
        confirmParams: {
          return_url: `${window.location.origin}/chat`,
        },
      });

      if (error) {
        console.error("Payment confirmation error:", error);
        if (error.type === 'card_error' || error.type === 'validation_error') {
          throw new Error(error.message);
        } else {
          throw new Error("An unexpected error occurred during payment processing");
        }
      }

    } catch (error: any) {
      console.error("Payment error:", error);
      toast({
        title: "Payment Failed",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    } finally {
      setIsLoading(null);
    }
  };

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 p-6 lg:p-8">
        <div className="max-w-5xl mx-auto space-y-8">
          <section className="text-center space-y-4">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Connect with Personal Sponsors
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Get personalized support from experienced recovery sponsors through secure messaging
            </p>
          </section>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="relative overflow-hidden">
              <CardHeader>
                <CardTitle>Single Message</CardTitle>
                <CardDescription>Perfect for occasional support</CardDescription>
                <div className="text-3xl font-bold">$5.99</div>
                <div className="text-sm text-muted-foreground">per message thread</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {[
                    "One support conversation thread",
                    "Response within 15min-2hrs",
                    "Secure messaging system",
                    "Access to support resources",
                  ].map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  className="w-full"
                  onClick={() => handlePayment("session")}
                  disabled={isLoading !== null}
                >
                  {isLoading === "session" ? "Processing..." : "Start Conversation"}
                </Button>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-2 border-primary">
              <div className="absolute top-0 right-0 px-3 py-1 bg-primary text-primary-foreground text-sm">
                Popular
              </div>
              <CardHeader>
                <CardTitle>Monthly Support</CardTitle>
                <CardDescription>Ongoing recovery guidance</CardDescription>
                <div className="text-3xl font-bold">$39</div>
                <div className="text-sm text-muted-foreground">per month</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {[
                    "Unlimited support conversations",
                    "Priority responses (within 15-30min)",
                    "Dedicated personal sponsor",
                    "Weekly check-ins",
                    "Custom recovery resources",
                    "Progress tracking",
                  ].map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button
                  className="w-full bg-primary hover:bg-primary/90"
                  onClick={() => handlePayment("subscription")}
                  disabled={isLoading !== null}
                >
                  {isLoading === "subscription" ? "Processing..." : "Start Monthly Support"}
                </Button>
              </CardContent>
            </Card>
          </div>

          <section className="mt-12 p-6 bg-card rounded-lg border text-center">
            <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
              Response times are based on Sponsor Pocket business hours (8 AM - 10 PM PST, seven days a week).
              All sponsors are experienced in recovery and vetted for their commitment to helping others. 
              Emergency resources are always available 24/7 through our AI support.
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}