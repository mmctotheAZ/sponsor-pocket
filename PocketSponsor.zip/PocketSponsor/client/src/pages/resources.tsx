import { Sidebar } from "@/components/ui/sidebar";
import { EmergencyResources } from "@/components/emergency-resources";

export default function Resources() {
  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-8 overflow-auto">
        <div className="max-w-4xl mx-auto space-y-8">
          <section className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Emergency Resources</h1>
            <p className="text-muted-foreground">
              Immediate help and support is available 24/7
            </p>
          </section>

          <EmergencyResources />

          <section className="mt-12 p-6 bg-muted rounded-lg text-center">
            <p className="text-sm text-muted-foreground">
              If you're experiencing a medical emergency or are in immediate danger,
              please call emergency services (911) immediately.
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}
