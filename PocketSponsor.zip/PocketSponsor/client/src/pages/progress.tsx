import { Sidebar } from "@/components/ui/sidebar";
import { ProgressTracker } from "@/components/progress-tracker";

export default function Progress() {
  // TODO: Get actual user ID from auth context
  const userId = 1;

  return (
    <div className="flex h-screen">
      <Sidebar />
      <main className="flex-1 p-8 overflow-auto">
        <div className="max-w-4xl mx-auto space-y-8">
          <section className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-2">Track Your Progress</h1>
            <p className="text-muted-foreground">
              Keep track of your journey and celebrate your milestones
            </p>
          </section>

          <ProgressTracker userId={userId} />
        </div>
      </main>
    </div>
  );
}
