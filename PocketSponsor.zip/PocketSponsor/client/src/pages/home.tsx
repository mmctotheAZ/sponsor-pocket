import { Sidebar } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, HeadphonesIcon } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 p-6 lg:p-8">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="flex items-center gap-3 mb-8">
            <img 
              src="/favicon.svg" 
              alt="SponsorPocket Logo" 
              className="w-10 h-10"
              width={40}
              height={40}
            />
            <h1 className="text-2xl font-bold text-foreground">
              Sponsor<span className="text-primary">Pocket</span>
            </h1>
          </div>
          <section className="text-center space-y-4">
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Your 24/7 companion on the journey of recovery. We're here to support you every step of the way.
            </p>
          </section>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="relative overflow-hidden border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <MessageCircle className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold">AI Sponsor Chat</h2>
                <p className="text-muted-foreground">
                  Connect with your AI sponsor for immediate guidance and support, available 24/7.
                </p>
                <Link href="/chat">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    <MessageCircle className="mr-2 h-4 w-4" />
                    Start Chat
                  </Button>
                </Link>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden border-2 border-primary/20 hover:border-primary/40 transition-colors">
              <CardContent className="p-6 space-y-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                  <HeadphonesIcon className="h-6 w-6 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold">Live Sponsor</h2>
                <p className="text-muted-foreground">
                  Connect with a real sponsor for personalized guidance and support.
                </p>
                <Link href="/pricing">
                  <Button className="w-full" variant="outline">
                    <HeadphonesIcon className="mr-2 h-4 w-4" />
                    Connect with Live Sponsor
                  </Button>
                </Link>
                <p className="text-xs text-muted-foreground text-center mt-2">
                  Premium feature - Connect with verified sponsors
                </p>
              </CardContent>
            </Card>
          </div>

          <section className="mt-12 p-6 bg-card rounded-lg border text-center">
            <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
              Remember: Sponsor Pocket is a supportive tool, not a replacement for professional help.
              Always reach out to emergency services when needed.
            </p>
          </section>
        </div>
      </main>
    </div>
  );
}