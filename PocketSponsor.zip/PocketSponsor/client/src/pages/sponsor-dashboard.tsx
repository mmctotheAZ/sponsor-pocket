import { useState } from "react";
import { Sidebar } from "@/components/ui/sidebar";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays, Clock, MessageSquare, User, BellOff } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function SponsorDashboard() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isAvailable, setIsAvailable] = useState(true);
  const { toast } = useToast();

  // Mock data for demonstration
  const pendingMessages = [
    {
      id: 1,
      time: "2:30 PM",
      user: "User1",
      status: "urgent",
      waitTime: "4h",
      message: "Struggling with a difficult situation..."
    },
    {
      id: 2,
      time: "1:15 PM",
      user: "User2",
      status: "new",
      waitTime: "5h",
      message: "Need guidance with Step 3..."
    }
  ];

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar />
      <main className="flex-1 p-6 lg:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold">Sponsor Dashboard</h1>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={isAvailable}
                  onCheckedChange={setIsAvailable}
                  id="availability"
                />
                <Label htmlFor="availability">Available for Support</Label>
              </div>
              <Badge variant={isAvailable ? "default" : "secondary"}>
                {isAvailable ? "Online" : "Away"}
              </Badge>
            </div>
          </div>

          <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold">Pending Messages</h3>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">8</div>
                <p className="text-sm text-muted-foreground">2 urgent</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold">Active Members</h3>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">12</div>
                <p className="text-sm text-muted-foreground">3 new this week</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold">Response Time</h3>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">4.2h</div>
                <p className="text-sm text-muted-foreground">Average</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold">Away Hours</h3>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">10</div>
                <p className="text-sm text-muted-foreground">10 PM - 8 AM PST</p>
              </CardContent>
            </Card>
          </section>

          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <h3 className="text-xl font-semibold">Availability Schedule</h3>
                <Button variant="outline" onClick={() => {
                  toast({
                    title: "Schedule Updated",
                    description: "Your availability hours have been saved.",
                  });
                }}>
                  Save Hours
                </Button>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border"
                />
                <div className="mt-4 space-y-2">
                  <Label>Away Hours (PST)</Label>
                  <div className="flex items-center space-x-2">
                    <BellOff className="h-4 w-4" />
                    <span>10:00 PM - 8:00 AM</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <h3 className="text-xl font-semibold">Message Queue</h3>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[400px] pr-4">
                  <div className="space-y-4">
                    {pendingMessages.map((message) => (
                      <div
                        key={message.id}
                        className="p-4 border rounded-lg space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <User className="h-4 w-4" />
                            <span className="font-medium">{message.user}</span>
                            <Badge variant={message.status === "urgent" ? "destructive" : "default"}>
                              {message.status}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>Waiting: {message.waitTime}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">{message.message}</p>
                        <Button
                          className="w-full mt-2"
                          onClick={() => {
                            toast({
                              title: "Opening conversation",
                              description: `Responding to ${message.user}...`,
                            });
                          }}
                        >
                          Respond Now
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}