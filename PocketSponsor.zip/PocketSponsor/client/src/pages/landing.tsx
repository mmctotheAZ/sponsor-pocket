import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { MessageCircle, Shield, Clock, Heart } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center gap-3 hover:opacity-90 transition-opacity">
              <img 
                src="/favicon.svg" 
                alt="SponsorPocket Logo" 
                className="w-10 h-10"
                width={40}
                height={40}
              />
              <h1 className="text-2xl font-bold text-foreground">
                Sponsor<span className="text-primary">Pocket</span>
              </h1>
            </div>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/pricing">
              <Button variant="ghost">Pricing</Button>
            </Link>
            <Link href="/chat">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="py-20 text-center">
          <div className="container mx-auto px-4">
            <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Recovery Within Reach
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-4">
              AI-guided support anytime, with real-life sponsors available when you need them.
            </p>
            <p className="text-lg text-primary mb-8">
              Like having a Sponsor in Your Pocket!
            </p>
            <div className="flex justify-center gap-4">
              <Link href="/chat">
                <Button size="lg" className="bg-primary hover:bg-primary/90">
                  Start Your Journey
                </Button>
              </Link>
              <Link href="/pricing">
                <Button size="lg" variant="outline">
                  View Plans
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/50">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="bg-background p-6 rounded-lg border">
                <MessageCircle className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">24/7 AI Support</h3>
                <p className="text-muted-foreground">
                  Immediate guidance using AA principles and literature, available anytime.
                </p>
              </div>
              <div className="bg-background p-6 rounded-lg border">
                <Shield className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Verified Sponsors</h3>
                <p className="text-muted-foreground">
                  Connect with experienced, vetted sponsors committed to your recovery.
                </p>
              </div>
              <div className="bg-background p-6 rounded-lg border">
                <Clock className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Quick Response</h3>
                <p className="text-muted-foreground">
                  Fast response times during business hours (8 AM - 10 PM PST).
                </p>
              </div>
              <div className="bg-background p-6 rounded-lg border">
                <Heart className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">Private & Secure</h3>
                <p className="text-muted-foreground">
                  Your privacy is our priority. All conversations are confidential.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join SponsorPocket today and get the support you need on your path to recovery.
            </p>
            <Link href="/chat">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Begin Now
              </Button>
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t py-8">
        <div className="container mx-auto px-4">
          <div className="text-center text-sm text-muted-foreground">
            <p className="mb-2">
              SponsorPocket is a supportive tool, not a replacement for professional help.
            </p>
            <p>
              If you're experiencing an emergency, please call 911 or visit our{" "}
              <Link href="/resources">
                <Button variant="link" className="h-auto p-0">
                  emergency resources
                </Button>
              </Link>
              .
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}